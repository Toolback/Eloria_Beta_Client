#!/bin/bash
sleep 3
./Eloria-Beta.exe