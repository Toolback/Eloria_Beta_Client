#!/bin/bash

./Eloria-Beta.exe